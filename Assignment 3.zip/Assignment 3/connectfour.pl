%20060155 Val Kobilaski
% Defining players
player(r).
player(y).

%The game starts with an empty board as red's turn
initial_state([-,-,-,-,-,-,-,-,-,-,-,-,-,-,-,-],r).
game_over(S,_,Q):- four_in_row(S,Q).
game_over(S,_,neither):- \+ legal_move(S,_,_,_).

% Horizontal Win conditions 
four_in_row([P,P,P,P,
            _,_,_,_,
            _,_,_,_,
            _,_,_,_],P):-player(P).

four_in_row([_,_,_,_,
            P,P,P,P,
            _,_,_,_,
            _,_,_,_],P):-player(P).
        
four_in_row([_,_,_,_,
            _,_,_,_,
            P,P,P,P,
            _,_,_,_],P):-player(P).
        
four_in_row([_,_,_,_,
            _,_,_,_,
            _,_,_,_,
            P,P,P,P],P):-player(P).
% Vertical win conditions         
four_in_row([P,_,_,_,
            P,_,_,_,
            P,_,_,_,
            P,_,_,_],P):-player(P).
        
four_in_row([_,P,_,_,
            _,P,_,_,
            _,P,_,_,
            _,P,_,_],P):-player(P).
                
four_in_row([_,_,P,_,
            _,_,P,_,
            _,_,P,_,
            _,_,P,_],P):-player(P).
                
four_in_row([_,_,_,P,
            _,_,_,P,
            _,_,_,P,
            _,_,_,P],P):-player(P).

%Diagonal win conditions          
four_in_row([_,_,_,P,
            _,_,P,_,
            _,P,_,_,
            P,_,_,_],P):-player(P).
        
four_in_row([P,_,_,_,
            _,P,_,_,
            _,_,P,_,
            _,_,_,P],P):-player(P).
% letters for rows and numbers for columns Ex.
/*
    [A1,A2,A3,A4]
    [B1,B2,B3,B4]
    [C1,C2,C3,C4]
    [D1,D2,D3,D4]
*/
%legal moves for first row 
legal_move([A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,'-',D2,D3,D4],P,1,[A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,P,D2,D3,D4]).
legal_move([A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,'-',D3,D4],P,2,[A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,P,D3,D4]).
legal_move([A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,'-',D4],P,3,[A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,P,D4]).
legal_move([A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,'-'],P,4,[A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,P]).
%legal moves for second row are only possible if the slot below is taken by either player
legal_move([A1,A2,A3,A4,B1,B2,B3,B4,'-',C2,C3,C4,D1,D2,D3,D4],P,1,[A1,A2,A3,A4,B1,B2,B3,B4,P,C2,C3,C4,D1,D2,D3,D4]):- \+ D1='-' .
legal_move([A1,A2,A3,A4,B1,B2,B3,B4,C1,'-',C3,C4,D1,D2,D3,D4],P,2,[A1,A2,A3,A4,B1,B2,B3,B4,C1,P,C3,C4,D1,D2,D3,D4]):- \+ D2='-' .
legal_move([A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,'-',C4,D1,D2,D3,D4],P,3,[A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,P,C4,D1,D2,D3,D4]):- \+ D3='-' .
legal_move([A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,'-',D1,D2,D3,D4],P,4,[A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,P,D1,D2,D3,D4]):- \+ D4='-' .
%legal moves for third row are only possible if the slot below is taken by either player
legal_move([A1,A2,A3,A4,'-',B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4],P,1,[A1,A2,A3,A4,P,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4]):- \+ C1='-' .
legal_move([A1,A2,A3,A4,B1,'-',B3,B4,C1,C2,C3,C4,D1,D2,D3,D4],P,2,[A1,A2,A3,A4,B1,P,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4]):- \+ C2='-' .
legal_move([A1,A2,A3,A4,B1,B2,'-',B4,C1,C2,C3,C4,D1,D2,D3,D4],P,3,[A1,A2,A3,A4,B1,B2,P,B4,C1,C2,C3,C4,D1,D2,D3,D4]):- \+ C3='-' .
legal_move([A1,A2,A3,A4,B1,B2,B3,'-',C1,C2,C3,C4,D1,D2,D3,D4],P,4,[A1,A2,A3,A4,B1,B2,B3,P,C1,C2,C3,C4,D1,D2,D3,D4]):- \+ C4='-' .
%legal moves for fourth row are only valid if the slot below is taken by either player
legal_move(['-',A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4],P,1,[P,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4]):- \+ B1='-' .
legal_move([A1,'-',A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4],P,2,[A1,P,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4]):- \+ B2='-' .
legal_move([A1,A2,'-',A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4],P,3,[A1,A2,P,A4,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4]):- \+ B3='-' .
legal_move([A1,A2,A3,'-',B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4],P,4,[A1,A2,A3,P,B1,B2,B3,B4,C1,C2,C3,C4,D1,D2,D3,D4]):- \+ B4='-' .