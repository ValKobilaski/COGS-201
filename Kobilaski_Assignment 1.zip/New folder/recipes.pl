
%PROVIDED CODE - DO NOT MODIFY

%Ingredients
meat(bacon).
meat(beef).
meat(sausage).
not_meat(X):- \+ meat(X).

spice(cayenne).
spice(cinnamon).
spice(curry).
spice(garlic).
spice(nutmeg).
spice(pepper).

% Recipes
recipe(banana_muffins,[baking_powder,banana,baking_soda,butter,chocolate,cinnamon,cocoa,eggs,flour,milk,salt,sugar,vanilla]).
recipe(brownies,[baking_powder,butter,chocolate,eggs,flour,sugar]).
recipe(pasta_casserole,[basil,beef,cayenne,cheese,garlic,onion,oregano,pasta,sausage,tomato]).
recipe(quiche,[bacon,butter,cheese,eggs,milk,onion,nutmeg,pepper,pie_crust]).
recipe(rice_dish,[curry,garlic,green_pepper,rice,oil,onion,peanut,raisin,vinegar]).
recipe(truffles,[chocolate,milk,vanilla]).

%ADD YOUR OWN CODE BELOW THIS LINE.

%Val Kobilaski

%vegetarian(Food):-recipe(Food,Ingredients),\+ (meat(X),member(X,Ingredients)).
%base case 
vegetarian([]).
% conditional to take in food name and pass on ingrediants
vegetarian(Food):-recipe(Food,Ingrediants),(vegetarian(Ingrediants)).
%recursive step, checks that the head is not meat and progresses through the list 
vegetarian([Head|Tail]):- \+meat(Head),vegetarian(Tail).

%Base case, head is a spice
spicy([Head|_]):-spice(Head).
%conditional to take in food name and pass on ingrediants
spicy(Food):-recipe(Food,Ingrediants),(spicy(Ingrediants)).
% recursive step, if head is not spicy progress through the list
spicy([Head|Tail]):- \+spice(Head),spicy(Tail).

%Base case, if head is a spice and the rest of the list is also spicy
very_spicy([Head|Tail]):-spice(Head),spicy(Tail).
%conditional to take in food name and pass on ingrediants
very_spicy(Food):-recipe(Food,Ingrediants),very_spicy(Ingrediants).
%recursive step, if head is not a spice move on
very_spicy([Head|Tail]):- \+spice(Head), very_spicy(Tail).

