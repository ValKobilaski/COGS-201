%Val Kobilski

%Cute atoms
cute(r2_D2).
cute(wAll_E).
%Intelligent atoms
intelligent(r2_D2).
intelligent(data).
%Dangerous atoms + conditionals
dangerous(terminator).
dangerous(Robot):-intelligent(Robot).
% has two arms atoms
has_two_arms(data).
has_two_arms(terminator).
%need to define annoting before using in a conditional
annoying(something).
%Conditional for famous takes either cute+ intelligent or dangerous and not annoying
famous(Robot):-(cute(Robot),intelligent(Robot));(dangerous(Robot),\+annoying(Robot)).